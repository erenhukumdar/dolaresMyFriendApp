class KairosFaceGallery:
    def __init__(self, gallery_name, subject_ids):
        self.name = gallery_name
        self.subjects = subject_ids
