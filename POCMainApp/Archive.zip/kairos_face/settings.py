app_id = "50c9d06f"
app_key = "b90f7bd696c853b8973ee8b93228c51a"
base_url = 'https://api.kairos.com/'
